package sistematico;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class datos extends personas{

	public datos(String nombre, int edad, String dNI) {
		super(nombre, edad, dNI);
		// TODO Auto-generated constructor stub
	}
	Scanner tc= new Scanner(System.in);
 public void pedir_datos() {
	 System.out.println("Ingrese su nombre");
	 nombre= tc.nextLine();
	 tc.hasNextLine();
	 System.out.println("Ingrese su edad \n"+ nombre);
	 edad= tc.nextInt();
	 tc.nextLine();
	 if (edad > 15) {
		 System.out.println("Ingrese su DNI");
		 DNI= tc.nextLine(); 
	 }
	
 }
 public void mostrar_datos() {
	 if (edad>17) {
		 System.out.println("Usted puede consumir alcohol");
	 }
	 System.out.println(nombre + "\n"+edad + "\n"+DNI);
 }
}

