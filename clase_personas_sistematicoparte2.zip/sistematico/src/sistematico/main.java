package sistematico;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     datos dat= new datos(null, 0, null);
     dat.pedir_datos();
     dat.mostrar_datos();
	}

}
